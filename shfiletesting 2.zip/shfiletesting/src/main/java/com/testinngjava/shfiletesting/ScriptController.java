package com.testinngjava.shfiletesting;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.InputStreamReader;

@RestController
public class ScriptController {
    @GetMapping("/run-script")
    public String runScript() {
        StringBuilder output = new StringBuilder();
        try {
            // relative path (works if you run app from project root)
            ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "scripts/hello.sh");
            processBuilder.redirectErrorStream(true);

            Process process = processBuilder.start();

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println("[SCRIPT] " + line); // logs in terminal
                    output.append(line).append("\n");
                }
            }

            int exitCode = process.waitFor();
            System.out.println("Script exited with code: " + exitCode);

        } catch (Exception e) {
            e.printStackTrace();
            return "Error running script: " + e.getMessage();
        }

        return output.toString();
    }
}
