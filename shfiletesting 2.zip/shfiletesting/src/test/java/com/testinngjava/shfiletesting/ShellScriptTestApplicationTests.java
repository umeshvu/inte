package com.testinngjava.shfiletesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShellScriptTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
